# 操作系统项目文档


操作系统（以下简称OS）是管理和控制计算机硬件与软件资源的计算机程序，直接运行在计算机硬件基础上，所有的其它程序都要在OS的支持下才能运行。通过一学期的操作系统课程学习，我们从OS的进程管理、内存管理、文件管理和设备管理等几个方面较为系统地了解了操作系统的原理。

本次项目的目标为实现一个简易完整的操作系统，旨在进一步了解操作系统的底层实现细节。我们基于Linux平台开发，在Bochs上实现了一个符合要求，功能完备的操作系统，并为其提供了较为良好的用户交互环境。本开发文档将从环境搭建，操作系统的实现和测试运行三个主要方面来进行组织和阐述。

本文档将分为以下几个部分进行陈述：

- 环境搭建
- 文件系统的改进
- 进程功能的改进
- 开关机动画
- 用户级应用
- 系统级应用
- 成员分工



## 环境搭建

本次课程设计的开发基于Linux平台，我们选择Ubuntu作为平台。

### Ubuntu环境搭建

我们选择VMware 15作为虚拟机来安装Ubuntu环境
  

### Bochs安装

Bochs是一个x86硬件平台的开源模拟器。它可以用来模拟各种硬件的配置。Bochs模拟的是整个PC平台，包括I/O设备、内存和BIOS。

在安装Bochs之前，我们需要先行安装以下四个插件：

```shell
sudo apt-get install build-essential
sudo apt-get install xorg-dev
sudo apt-get install bison
sudo apt-get install libgtk2.0-dev
```

然后我们需要到[Bochs的官网上下载，这里我们选择的是bochs-2.6.11版本的。下载完成后，我们在其所在文件目录下执行以下命令：

```shell
tar vxzf bochs-2.6.11.tar.gz
cd bochs-2.6.11
./configure --enable-debugger --enable-disam
make
sudo make install
```

这样Bochs的搭建基本完成了。



## 文件系统的改进

文件系统部分，我们基于Orange给出的代码，根据我们对文件系统的理解，作出了一些修改

**实现思路**

- > 添加新建文件(nf),创建CreateFile函数，将文件名和路径合并，调用PUBLIC int open(const char *pathname, int flags)函数，判断该文件名是否存在，不存在则调用PUBLIC int write(int fd, const void *buf, int count)，修改文件描述符，之后调用PUBLIC int close(int fd)，关闭文件描述符，文件创建成功，若存在则输出相关信息。
```c
void CreateFile(char* path, char* file)//新建文件
{
	char absoPath[512];
	addTwoString(absoPath, path, file);

	int fd = open(absoPath, O_CREAT | O_RDWR);

	if (fd == -1)
	{
		printf("Failed to create a new file with name %s\n", file);
		return;
	}

	char buf[1] = { 0 };
	write(fd, buf, 1);
	printf("File created: %s (fd %d)\n", file, fd);
	close(fd);
}
```
- > 删除文件或目录(rm),创建DeleteFile函数，将文件名与路径合并，调用PUBLIC int unlink(const char * pathname)函数，判断该文件是否存在，存在则修改其文件描述符，不存在则输出相关信息。
```c
void DeleteFile(char* path, char* file)//删除文件
{
	char absoPath[512];
	addTwoString(absoPath, path, file);
	int m = unlink(absoPath);
	if (m == 0)
		printf("%s deleted!\n", file);
	else
		printf("Failed to delete %s!\n", file);
}
```
- > 写文件(wf)，创建WriteFile函数，将文件名与路径合并，调用PUBLIC int open(const char *pathname, int flags)函数，判断该文件是否存在，存在则调用PUBLIC int read(int fd, void *buf, int count)写入缓冲区，若该文件不存在则输出相关信息。
```c
void WriteFile(char* path, char* file)//写文件
{
	char absoPath[512];
	addTwoString(absoPath, path, file);
	int fd = open(absoPath, O_RDWR);
	if (fd == -1)
	{
		printf("Failed to open %s!\n", file);
		return;
	}

	char tty_name[] = "/dev_tty0";
	int fd_stdin = open(tty_name, O_RDWR);
	if (fd_stdin == -1)
	{
		printf("An error has occured in writing the file!\n");
		return;
	}
	char writeBuf[4096];  // 写缓冲区
	int endPos = read(fd_stdin, writeBuf, 4096);
	writeBuf[endPos] = 0;
	write(fd, writeBuf, endPos + 1);  // 结束符也应写入
	close(fd);
}
```
- > 读文件(pfc),创建ReadFile函数，将文件名与路径合并，调用PUBLIC int open(const char *pathname, int flags)函数，判断该文件名是否存在，存在则调用PUBLIC int read(int fd, void *buf, int count)函数，读出文件内容，否则输出相关信息。
```c
void ReadFile(char* path, char* file)//读文件
{
	char absoPath[512];
	addTwoString(absoPath, path, file);
	int fd = open(absoPath, O_RDWR);
	if (fd == -1)
	{
		printf("Failed to open %s!\n", file);
		return;
	}

	char buf[4096];
	int n = read(fd, buf, 4096);
	if (n == -1)  // 读取文件内容失败
	{
		printf("An error has occured in reading the file!\n");
		close(fd);
		return;
	}

	printf("%s\n", buf);
	close(fd);
}
```
- > 创建目录（mkdir）,创建CreateDir函数，将文件名与路径合并，，调用PUBLIC int open(const char *pathname, int flags)函数，判断该目录名是否存在，不存在则调用PUBLIC int write(int fd, const void *buf, int count)，修改文件描述符，目录创建成功，否则输出相关信息。
```c
void CreateDir(char* path, char* file)//新建目录
{
	char absoPath[512];
	addTwoString(absoPath, path, file);
	int fd = open(absoPath, O_RDWR);

	if (fd != -1)
	{
		printf("Failed to create a new directory with name %s\n", file);
		return;
	}
	mkdir(absoPath);
}
```
- > 切换当前目录（cd）,创建ChangeDir函数，在当前目录判断所有的文件节点是否所要切换的目录，如果找到进入该目录，否则输出相关错误信息。 
```c
void ChangeDir(char* path, char* file)//切换当前目录
{
	int flag = 0;  // 判断是进入下一级目录还是返回上一级目录
	char newPath[512] = { 0 };
	if (file[0] == '.' && file[1] == '.')  // cd ..返回上一级目录
	{
		flag = 1;
		int pos_path = 0;
		int pos_new = 0;
		int i = 0;
		char temp[128] = { 0 };  // 用于存放某一级目录的名称
		while (path[pos_path] != 0)
		{
			if (path[pos_path] == '/')
			{
				pos_path++;
				if (path[pos_path] == 0)  // 已到达结尾
					break;
				else
				{
					temp[i] = '/';
					temp[i + 1] = 0;
					i = 0;
					while (temp[i] != 0)
					{
						newPath[pos_new] = temp[i];
						temp[i] = 0;  
						pos_new++;
						i++;
					}
					i = 0;
				}
			}
else
{
				temp[i] = path[pos_path];
				i++;
				pos_path++;
			}
		}
	}
	char absoPath[512];
	char temp[512];
	int pos = 0;
	while (file[pos] != 0)
	{
		temp[pos] = file[pos];
		pos++;
	}
	temp[pos] = '/';
	temp[pos + 1] = 0;
	if (flag == 1)  // 返回上一级目录
	{
		temp[0] = 0;
		addTwoString(absoPath, newPath, temp);
	}
	else  // 进入下一级目录
		addTwoString(absoPath, path, temp);
	int fd = open(absoPath, O_RDWR);
	if (fd == -1)
		printf("%s is not a directory!\n", absoPath);
	else
		memcpy(path, absoPath, 512);
}
```
- > 将扁平式文件系统修改为**多级文件系统**

**效果展示**

#### 新建文件
   <img src='nf.png'>

#### 写入文件内容并读出文件内容
   <img src='wf.png'>




## 进程功能的改进

进程的管控在操作系统中至关重要，对于进程部分，我们参考Orange，并在其基础上进行了如下方面的完善：

- 提供了针对每一个用户进程的``pause``、``kill``、``resume``和``up``操作
- 提供了展示``process_table``内容信息的命令，用户可以直接调用

我们在Orange原有的进程结构上做了一定的改动，增加了``run_count``和``run_state``属性，前者用来记录进程的运行时间，后者用来跟进进程的运行状态信息。

初始化完成后，系统中共存在7个进程，其中包括4个系统进程，即：TTY、SYS、HD和FS，以及3个用户进程，分别为TestA、TestB和TestC。系统进程的``priority``为20，而用户进程的``priority``设置为10。

<img src='process.png'>
开机启动时，``kernel/main.c``中的``kernel_main``函数会启动进程并执行对进程的初始化操作。




```c
PUBLIC int kernel_main() {
    disp_str("-----\"kernel_main\" begins-----\n");

    struct task* p_task;
    struct proc* p_proc= proc_table;
    char* p_task_stack = task_stack + STACK_SIZE_TOTAL;
    u16   selector_ldt = SELECTOR_LDT_FIRST;
    u8    privilege;
    u8    rpl;
    int   eflags;
    int   i, j;
    int   prio;

    // start the process
    for (i = 0; i < NR_TASKS+NR_PROCS; i++) {

        if (i < NR_TASKS) {
            /* task */
            p_task    = task_table + i;
            privilege = PRIVILEGE_TASK;
            rpl       = RPL_TASK;
            eflags    = 0x1202; 
            prio      = 20;     
        }
        else {

            /* user process */
            p_task    = user_proc_table + (i - NR_TASKS);
            privilege = PRIVILEGE_USER;
            rpl       = RPL_USER;
            eflags    = 0x202; 
            prio      = 10;     
        }

        strcpy(p_proc->name, p_task->name); 
        p_proc->pid = i;            
        p_proc->run_count = 0;
        p_proc->ldt_sel = selector_ldt;
        memcpy(&p_proc->ldts[0], &gdt[SELECTOR_KERNEL_CS >> 3], sizeof(struct descriptor));
        p_proc->ldts[0].attr1 = DA_C | privilege << 5;
        memcpy(&p_proc->ldts[1], &gdt[SELECTOR_KERNEL_DS >> 3],sizeof(struct descriptor));
        p_proc->ldts[1].attr1 = DA_DRW | privilege << 5;
        p_proc->regs.cs = (0 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
        p_proc->regs.ds = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
        p_proc->regs.es = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
        p_proc->regs.fs = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
        p_proc->regs.ss = (8 & SA_RPL_MASK & SA_TI_MASK) | SA_TIL | rpl;
        p_proc->regs.gs = (SELECTOR_KERNEL_GS & SA_RPL_MASK) | rpl;
        p_proc->regs.eip = (u32)p_task->initial_eip;
        p_proc->regs.esp = (u32)p_task_stack;
        p_proc->regs.eflags = eflags;
        p_proc->p_flags = 0;
        p_proc->p_msg = 0;
        p_proc->p_recvfrom = NO_TASK;
        p_proc->p_sendto = NO_TASK;
        p_proc->has_int_msg = 0;
        p_proc->q_sending = 0;
        p_proc->next_sending = 0;

        for (j = 0; j < NR_FILES; j++)
            p_proc->filp[j] = 0;

        p_proc->ticks = p_proc->priority = prio;
        p_proc->run_state = 1;
        p_task_stack -= p_task->stacksize;
        p_proc++;
        p_task++;
        selector_ldt += 1 << 3;

    }

    proc_table[4].run_state = 1;
    proc_table[5].run_state = 0;

    // init process
    k_reenter = 0;
    ticks = 0;
    p_proc_ready = proc_table;

    init_clock();
    init_keyboard();

    restart();

    while(1){}
}
```

初始化状态下运行TestA和TestB进程，该进程分别与``/dev/tty0``和``/dev/tty1``相连，负责初始化shell并与用户进行交互，其具体实现封装在函数shell中。

进程的调度实现，我们参考了Orange的进程调度：

```C
PUBLIC void schedule()
{
	struct proc*	p;
	int		greatest_ticks = 0;
	while (!greatest_ticks) {
		for (p = &FIRST_PROC; p <= &LAST_PROC; p++) {
			if (p->p_flags == 0) {
				if (p->ticks > greatest_ticks) {
					greatest_ticks = p->ticks;
					p_proc_ready = p;
				}
			}
		}
		if (!greatest_ticks)
			for (p = &FIRST_PROC; p <= &LAST_PROC; p++)
				if (p->p_flags == 0)
					p->ticks = p->priority;
	}
}
```

针对用户进程（TestA、TestB和TestC），我们提供了四个基础操作，具体实现细节如下。

### pause指令

pause指令负责暂时挂起进程，并对进程进行调度。我们主要通过block来实现进程的pause指令，同时在完成block之后，我们对``process_table``中相应元素的项进行修改，即``run_state``的值。

### kill指令

kill指令负责杀死（关闭）进程，并释放进程所占用的资源。同时，在关闭进程后，我们要对引用计数的值-1。

### resume指令

resume指令和pause指令相对应，当某一用户进程处于挂起状态时，用户可以执行rsume命令来继续运行进程。我们通过ublock来实现进程的resume指令，同时在完成block之后会修改``run_state``的值。

### up指令

up指令用于提高进程的优先级，对应其``proc``中的``priority``属性，单次执行该条指令会将对应进程的优先级提高一倍。

在上述用户级指令执行过程中，会涉及到进程的切换过程，除了Orange提供的，系统系统级别的进程调度之外（根据进程优先级），我们实现了进程切换函数：

```C
void swtch_to(struct proc *target_pro){
    struct proc *org_pro;
    TSS.ESP0 = (uint)target)_pro + PAGE; 
    org_pro = cu;
    cu = target_pro;
    lpgd(target_pro->p_vm.vm_pgd);
    _do_swtch(&(org_pro->p_context), &(target_pro->p_context));
}
```

``_do_swtich()``是一段汇编例程，它负责将当前的上下文保存到``org_pro->p_context``，同时将``target_pro->p_context``中保存的上下文恢复出来，也就是真正发生进程切换的地方。



## 用户级应用

在操作系统中，我们内置了4个用户级应用，分别是：

- `snake` 贪吃蛇小游戏 
- `minesweeper` 扫雷小游戏
- `calculator` 计算器
- `sokoban` 推箱子

上述小游戏均通过`a` `s` `d` `w` 键模拟上下左右，通过即时刷新的字符阵列模拟友好的游戏图形界面。

### 贪吃蛇小游戏

贪吃蛇小游戏是一款经典的益智游戏，该游戏通过控制蛇头方向吃蛋，从而使得蛇变得越来越长。
<img src='snake.png'>

该部分的代码位于``main.c``中，其实现主要涉及以下的几个函数：

1. **``judgeInpt``函数**

   监听键盘输入一个字符，用来判断用户操作蛇头的移动方向，``a`` 代表向左，`s`代表向下，``d``代表向右，``w``代表向上，其他输入字符忽略。

   ```c
   PUBLIC void judgeInpt(u32 key) {
       char output[2] = {'\0', '\0'};
       if (!(key & FLAG_EXT)) {
           output[0] = key & 0xFF;
           if(output[0] == 'a') changeToLeft();
           if(output[0] == 's') changeToDown();
           if(output[0] == 'd') changeToRight();
           if(output[0] == 'w') changeToUp();
       }
   }
   
   int listenerStart = 0;
   ```

2. **涉及方向变化的四个函数**

   **``changeToLeft``**、**``changeToDown``** 、**``changeToRight``**、**``changeToUp``**四个函数用于控制蛇头方向的变化，在当轮监听到用户输入的方向后响应。

   ```c
   //change the direction of circle
   void changeToLeft(){
       if(listenerStart == 1){
           Snake[0].now = 0;
           listenerStart = 0;
       }
   }
   void changeToDown(){
       if(listenerStart == 1){
           Snake[0].now = 3;
           listenerStart = 0;
       }
   }
   void changeToRight(){
       if(listenerStart == 1){
           Snake[0].now = 1;
           listenerStart = 0;
       }
   }
   void changeToUp(){
       if(listenerStart == 1){
           Snake[0].now = 2;
           listenerStart = 0;
       }
   }
   ```

3. **``move``函数**

   该函数控制蛇在上下左右移动时蛇头和蛇身的位置的改变等等。

   ```c
   void move(){
       int i, x, y;  
       int t = sLength;
       x = Snake[0].x;  
       y = Snake[0].y;  
       Snake[0].x = Snake[0].x + dx[Snake[0].now]; 
       Snake[0].y = Snake[0].y + dy[Snake[0].now];  
   
       Map[x][y] = '.'; 
       checkBorder(); 
       checkHead(x, y);   
       if(sLength == t)  //did not eat
           for(i = 1; i < sLength; i++){
               if(i == 1)   //tail  
                   Map[Snake[i].x][Snake[i].y] = '.';  
        
               if(i == sLength-1)  //the node after the head 
               {  
                   Snake[i].x = x;  
                   Snake[i].y = y;  
                   Snake[i].now = Snake[0].now;  
               }  
               else 
               {  
                   Snake[i].x = Snake[i+1].x;  
                   Snake[i].y = Snake[i+1].y;  
                   Snake[i].now = Snake[i+1].now;  
               }  
               Map[Snake[i].x][Snake[i].y] = sBody;  
           }  
   }
   ```

4. **``show``函数**

   用于控制用户界面的显示和刷新频率，界面刷新频率与蛇身长度相关；此外，这部分代码还将判断游戏是否结束，即蛇头是否触及舍身或所有的食物都已吃完，从而显示游戏结束的界面。

   ```c
   void show(){
       int i, j; 
       printf("Load snake game ...");
       while(1){
           listenerStart = 1;
   
           if(eat < 5){
               milli_delay(8000);
           }else if(eat < 10){
               milli_delay(6000);
           }else{
               milli_delay(5000);
           }
           move();  
           if(overOrNot) 
           {
               showGameOver();
               milli_delay(50000);
               clear();
               break;  
           } 
           if(eat == win)
           {
               showGameSuccess();
               milli_delay(50000);
               clear();
               break;
           }
           clear();
           for(i = 0; i < mapH; i++)   
           {   
               for(j = 0; j < mapW; j++)  
               printf("%c", Map[i][j]);  
               printf("\n");  
           }  
   
           printf("Have fun!\n");
           printf("You have ate:%d\n",eat);
       }  
   }
   ```

5. **``checkBorder``函数和``checkHead``函数**

   根据贪吃蛇游戏的规则，游戏会在两种情况下结束：当所有的食物被吃光，游戏者成功；当蛇头触及蛇身或墙壁周围，游戏者失败。该部分涉及的两个函数分别用于判断蛇头是否触及蛇身或墙壁。

   ```c
   void checkBorder(){
       if(Snake[0].x < 0 || Snake[0].x >= mapH || Snake[0].y < 0 || Snake[0].y >= mapW){
           printl("game over!");
           overOrNot = 1;  
       }
       
   }
   
   void checkHead(int x, int y){
       if(Map[Snake[0].x][Snake[0].y] == '.')
           Map[Snake[0].x][Snake[0].y] = sHead ;  
       else if(Map[Snake[0].x][Snake[0].y] == sFood) {
           Map[Snake[0].x][Snake[0].y] = sHead ;    
           Snake[sLength].x = x;                //new node
           Snake[sLength].y = y;  
           Snake[sLength].now = Snake[0].now;  
           Map[Snake[sLength].x][Snake[sLength].y] = sBody;   
           sLength++;  
           initFood();  
       }  
       else{ 
           overOrNot = 1; 
       }
   }
   ```

6. **``showGameOver``函数和``showGameSuccess``函数**

   用于显示游戏结束后的用户友好界面。

   ```c
   void showGameOver(){
       printf("===================================================\n");
       printf("======================Game Over====================\n");
       printf("=============will exit in 3 seconds...=============\n");
   }
   
   void showGameSuccess(){
       printf("===================================================\n");
       printf("==================Congratulation!==================\n");
       printf("=============will exit in 3 seconds...=============\n"); 
   }
   ```

7. **游戏的数据和界面的初始化**

   ```c
   struct Snake{   //every node of the snake 
       int x, y;  
       int now;   //0,1,2,3 means left right up down   
   }Snake[15*35];  //Snake[0] is the head，and the other nodes are recorded in inverted order，eg: Snake[1] is the tail
   
   const int mapH = 15;
   const int mapW = 35;
   char sHead = '@';
   char sBody = 'O';
   char sFood = '$';
   char sNode = '.';    
   char Map[15][35]; // the map of snake
   int food[15][2] = {{5, 13},{6, 10}, {17, 15}, {8, 9}, {3, 4}, {1,12}, {0, 2}, {5, 23},{15, 13},{16, 10}, {7, 15}, {8, 19}, {3, 14}, {11,12}, {10, 2}};
   int foodNum = 0;
   int eat = -1;
   int win = 15;  // the length of win
    
   int sLength = 1;
   int overOrNot = 0;
   int dx[4] = {0, 0, -1, 1};  
   int dy[4] = {-1, 1, 0, 0}; 
   
   void initGame(); 
   void initFood();
   void show();
   void move();
   void checkBorder();
   void checkHead(int x, int y);
   void action();
   void showGameSuccess();
   void showGameSuccess();
   
   void snakeGame(){
       clear();
       initGame();  
       show(); 
   }
   void initGame() {
       int i, j;  
       int headx = 5;
       int heady = 10;
       memset(Map, '.', sizeof(Map));   //init map with '.'
       Map[headx][heady] = sHead;  
       Snake[0].x = headx;  
       Snake[0].y = heady;  
       Snake[0].now = -1;
       initFood();   //init target 
       for(i = 0; i < mapH; i++){
           for(j = 0; j < mapW; j++)  
               printf("%c", Map[i][j]);  
           printf("\n");  
       } 
       printf("press 'a''s''d''w' key and start the game\n");
       listenerStart = 1;
       while(listenerStart);
   }
   void initFood(){
       int fx, fy;
       int tick;  
       while(1){
           tick = get_ticks();
           fx = tick%mapH;
           fy = tick%mapW;     
           if(Map[fx][fy] == '.'){
               eat++;
               Map[fx][fy] = sFood;  
               break;  
           }
           foodNum++;
       }
   }
   ```






### 扫雷小游戏

《扫雷》是一款大众类的益智小游戏，于1992年发行。游戏目标是在最短的时间内根据点击格子出现的数字找出所有非雷格子，同时避免踩雷，踩到一个雷即全盘皆输。在这里，我们通过字符模拟扫雷棋盘，通过输入坐标模拟鼠标点击。

<img src='ms.png'>



该部分的代码位于``main.c``中，代码如下：

```c
void srand(unsigned int seed){
	_seed2 = seed;
}

int rand() {
	int next = _seed2;
	int result;

	next *= 1103515245;
	next += 12345;
	result = (next / 65536) ;

	next *= 1103515245;
	next += 12345;
	result <<= 10;
	result ^= (next / 65536) ;

	next *= 1103515245;
	next += 12345;
	result <<= 10;
	result ^= (next / 65536) ;

	_seed2 = next;

	return result>0 ? result : -result;
}

void show_mat(int *mat,int *mat_state, int touch_x,int touch_y,int display){
	int x, y;
	for (x = 0; x < 10; x++){
		printf("  %d", x);
	}
	printf("\n");
	for (x = 0; x < 10; x++){
		printf("---");
	}
	for (x = 0; x < 10; x++){
		printf("\n%d|", x);
		for (y = 0; y < 10; y++){
			if (mat_state[x * 10 + y] == 0){				
					if (x == touch_x && y == touch_y)
						printf("*  ");
					else if (display!=0 && mat[x * 10 + y] == 1)
						printf("#  ");
					else
						printf("-  ");
				
			}
			else if (mat_state[x * 10 + y] == -1){
				printf("O  ");
			}
			else{
				printf("%d  ", mat_state[x * 10 + y]);
			}
			
		}
	}
	printf("\n");
}

void init_game(int *mat, int mat_state[100]){
	int sum = 0;
	int x, y;
	for (x = 0; x < 100; x++)
		mat[x] = mat_state[x] = 0;
	while (sum < 15){
		x = rand() % 10;
		y = rand() % 10;
		if (mat[x * 10 + y] == 0){
			sum++;
			mat[x * 10 + y] = 1;
		}
	}
	show_mat(mat,mat_state,-1,-1,0);
}

int check(int x, int y, int *mat){
	int i, j,now_x,now_y,result = 0;
	for (i = -1; i <= 1; i++){
		for (j = -1; j <= 1; j++){
			if (i == 0 && j == 0)
				continue;
			now_x = x + i;
			now_y = y + j;
			if (now_x >= 0 && now_x < 10 && now_y >= 0 && now_y <= 9){
				if (mat[now_x * 10 + now_y] == 1)
					result++;
			}
		}
	}
	return result;
}

void dfs(int x, int y, int *mat, int *mat_state,int *left_coin){
	int i, j, now_x, now_y,temp;
	if (mat_state[x*10+y] != 0)
		return;
	(*left_coin)--;
	temp = check(x, y,mat);
	if (temp != 0){
		mat_state[x * 10 + y] = temp;
	}
	else{
		mat_state[x * 10 + y] = -1;
		for (i = -1; i <= 1; i++){
			for (j = -1; j <= 1; j++){
				if (i == 0 && j == 0)
					continue;
				now_x = x + i;
				now_y = y + j;
				if (now_x >= 0 && now_x < 10 && now_y >= 0 && now_y <= 9){				
					dfs(now_x, now_y,mat,mat_state,left_coin);
				}
			}
		}
	}
}

void game(int fd_stdin){
	int mat[100] = { 0 };
	int mat_state[100] = { 0 };
	char keys[128];
	int x, y, left_coin = 100,temp;
	int flag = 1;

	while (flag == 1){
		init_game(mat, mat_state);
		left_coin = 100;
		printf("-------------------------------------------\n\n");
		printf("Input next x and y: ");

		while (left_coin != 15){

		clearArr(keys, 128);
                int r = read(fd_stdin, keys, 128);
		if(keys[0] == 'q'){
			break;
		}else if(keys[0]>'9'||keys[0]<'0'||keys[1]!=' '||keys[2]>'9'||keys[2]<'0'||keys[3]!=0){
                	printf("Please input again!\n");
    			continue;
            	}
            x = keys[0]-'0';
            y = keys[2]-'0';
			if (x < 0 || x>9 || y < 0 || y>9){
				printf("Please input again!\n");
				continue;
			}

			if (mat[x * 10 + y] == 1){
				break;
			}
			else{
				dfs(x, y, mat, mat_state, &left_coin);
				if (left_coin <= 15)
					break;
				show_mat(mat, mat_state, -1, -1, 0);
				printf("-------------------------------------------\n\n");
				printf("Input next x and y: ");
			}
		}
		if (mat[x * 10 + y] == 1){
			printf("\n\nFAIL!\n");
			show_mat(mat, mat_state, x, y, 1);
		}
		else{
			printf("\n\nSUCCESS!\n");
			show_mat(mat, mat_state, -1, -1, 1);
		}

		printf("Do you want to continue?(yes ot no)\n");
		clearArr(keys, 128);
        int r = read(fd_stdin, keys, 128);
        //  printf("%s\n",keys);
        if (keys[0]=='n' && keys[1]=='o' && keys[2]==0)
        {
        	flag = 0;
        //	printf("%s\n",keys);
            break;
        }
	}	
}
```

### 计算器

以#号结尾，输入一串十以内加减乘除算式，按Enter键即可获得计算结果。

<img src='calculator.bmp'>

该部分的代码位于'main.c'中，代码如下：

```c
stack calStack;
char calStr[STACK_DEFAULT_SIZE];
int p_str;

boolean isdigit(ch){
    return ch<='9' && ch >='0';
}

int isp(char ch){
    if(ch == '+')
    	return 1;
    if(ch == '-')
    	return 2;
    if(ch == '*')
    	return 3;
    if(ch == '/')
    	return 4;
    if(ch == '('|| ch == ')')
    	return 0;
    if(ch == '#')
    	return -1;
    
}

void push(stack *sk, char ch){
    sk->s[sk->top++]=ch;
    assert(sk->top<STACK_DEFAULT_SIZE);
}

char top(stack *sk){
    assert(top!=0);
    return sk->s[sk->top-1];
}

char pop(stack *sk){
    assert(top!=0);
    return sk->s[--sk->top];
}

void init_stack(stack *sk){
    sk->top = 0;
}

void show_stack(){
    int i;
    for(i = 0 ; i < calStack.top; ++i){
        printf("%c", calStack.s[i]);
    }
    printf("\n");
}

char *postfix(char *str){
    init_stack(&calStack);
    char *p = str;
    char *q = calStr;
    push(&calStack, '#');
    while(calStack.top!=0&&*p!='#'){
        if(isdigit(*p)){
            *q++=*p++;
        }
        else{
            char op = top(&calStack);
            if(isp(op)<isp(*p))
                push(&calStack, *p++);
            else if(isp(op) > isp(*p) && *p!='('){
                *q++ = pop(&calStack);
                
            }else{
                char op = top(&calStack);
                if(op == '(')p++;
                else *q++=pop(&calStack);
            }
        }
    }
    while(calStack.top!=0){
        // printf("%c\n", top(&calStack));
        *q++=pop(&calStack);
    }
    *q = '\0';
    return calStr;
}

void do_operator(char op){
    int right = pop(&calStack);
    int left = pop(&calStack);
    // printf("%d %d\n", left, right);
    int value;
    switch(op){
        case '+':
            value = left + right;
            push(&calStack, value);
            break;
        case '-':
            value = left - right;
            push(&calStack, value);
            break;
        case '*':
            value = left * right;
            push(&calStack, value);
            break;
        case '/':
            if(right == 0){
                printf("divide by 0!\n");
            }
            else{
                value = left / right;
                push(&calStack, value);
            }
            break;
    }
}

void calculate(char *str){
    char *s = postfix(str);
    // printf("%s\n", s);
    // while(1);
    p_str = 0;
    init_stack(&calStack);
    char *p = s;
    while(*p!='#'){
        switch(*p){
            case '+':
            case '-':
            case '*':
            case '/':
                do_operator(*p++);
                break;
            default:
                push(&calStack, (*p-'0'));
                p++;
                // printf("stack top: %d\n", top(&calStack));
        }
    }
    printf("%d\n", top(&calStack));
}

void Calculator(){
	
	char rdbuf[512];
	
	int fd_stdin = 0;
	
	printf("This is a Calculator application\n");
	printf("The expression must end with #\n");
	
	
	while(1){
        	clearArr(rdbuf, 512);
        	
        	printf("> ");
        	int r = read(fd_stdin, rdbuf, 512);
		if (strcmp(rdbuf, "") == 0)
			continue;
		
        	calculate(rdbuf);
	}
}
```
### 推箱子

当所有的箱子被推倒相应位置的时候，游戏成功，否则游戏失败，要重新进行或者退出。

<img src='sokoban.png'>

该部分的代码位于`sokoban.h`中，其主要代码如下：
```
PUBLIC void sokoban() {
	int i = 0;
	int choice = 0;
	MenuUi();
	Game();
}
void InitData() {
	int i, j;
	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COL; j++) {
			if (map[i][j] == 2) {
				x = j;
				y = i;
			}

			if (map[i][j] == 3) {
				Boxs++;
			}
		}
	}
}
void drawMap() {
	int i, j;
	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COL; j++) {
			switch (map[i][j]) {
			case 0:
				printf("  ");
				break;
			case 1:
				printf("|");
				break;
			case 2:
				printf("@");
				break;
			case 3:
				printf("#");
				break;
			case 4:
				printf("$");
				break;
			case 5:
				printf("&");
				break;
			}
		}
		printf("\n");
	}
}

void MoveUp() {
	if (y == 0) {
		return;
	}
	int Ux = x;
	int Uy = y - 1;
	if (map[Uy][Ux] == 1 || map[Uy][Ux] == 5) {
		return;
	}
	if (map[Uy][Ux] == 3) {
		if (map[Uy - 1][Ux] == 1) {
			return;
		}
		if (map[Uy - 1][Ux] == 4) {
			map[Uy - 1][Ux] = 5;
			Boxs--;
		}
		else {
			map[Uy - 1][Ux] = 3;
		}
	}
	map[y][x] = 0;
	map[Uy][Ux] = 2;
	y = Uy;
}

void MoveDown() {
	int D = MAX_ROW - 1;
	if (y == D) {
		return;
	}
	int Dx = x;
	int Dy = y + 1;
	if (map[Dy][Dx] == 1 || map[Dy][Dx] == 5) {
		return;
	}
	if (map[Dy][Dx] == 3) {
		if (map[Dy + 1][Dx] == 1) {
			return;
		}
		if (map[Dy + 1][Dx] == 4) {
			map[Dy + 1][Dx] = 5;
			Boxs--;
		}
		else {
			map[Dy + 1][Dx] = 3;
		}
	}
	map[y][x] = 0;
	map[Dy][Dx] = 2;
	y = Dy;
}


void MoveLeft() {
	if (x == 0) {
		return;
	}
	int Lx = x - 1;
	int Ly = y;

	if (map[Ly][Lx] == 1 || map[Ly][Lx] == 5) {
		return;
	}
	if (map[Ly][Lx] == 3) {
		if (map[Ly][Lx - 1] == 1) {
			return;
		}
		if (map[Ly][Lx - 1] == 4) {
			map[Ly][Lx - 1] = 5;
			Boxs--;
		}
		else {
			map[Ly][Lx - 1] = 3;
		}
	}
	map[y][x] = 0;
	map[Ly][Lx] = 2
	x = Lx;
}


void MoveRight() {
	int R = MAX_COL - 1;
	if (x == R) {
		return;
	}
	int Rx = x + 1;
	int Ry = y;
	if (map[Ry][Rx] == 1 || map[Ry][Rx] == 5) {
		return;
	}
	if (map[Ry][Rx] == 3) {
		if (map[Ry][Rx + 1] == 1) {
			return;
		}
		if (map[Ry][Rx + 1] == 4) {
			map[Ry][Rx + 1] = 5;
			Boxs--;
		}
		else {
			map[Ry][Rx + 1] = 3;
		}
	}
	map[y][x] = 0;
	map[Ry][Rx] = 2;
	x = Rx;
}



void Game() {
	char direction[2] = "";
	InitData();
	while (1) {
		drawMap();
		printf("请输入你所需要移动的方向(小写字母)：（W为上，A为左，S为下，D为右）\n");
		if (!Boxs) {
			break;
		}
		read(3, direction, 1);
		switch (direction[0]) {
		case 'w':
			MoveUp();
			break;
		case 'a':
			MoveLeft();
			break;
		case 's':
			MoveDown();
			break;
		case 'd':
			MoveRight();
			break;
		}
	}
	printf("您已通关游戏!\n");
}
```

## 开/关机动画
在本次项目中，我们分别实现了开机动画和关机动画。
### 关机画面

当在终端输入shutdown后，系统页面会清空并显示出关机画面。通过三次printf操作展现出一种动画效果。

<img src='shutdown.bmp'>

此段代码在'main.c'中，代码如下：

```c
void displayGoodBye()
{

    clear();
    printf("\n\n\n\n\n");
    printf("            BBBBBB					\n");
    printf("            B     B					\n");
    printf("            B      B					\n");
    printf("            B      B					\n");
    printf("            B     B					\n");
    printf("            BBBBBB					\n");
    printf("            B     B					\n");
    printf("            B      B					\n");
    printf("            B      B					\n");
    printf("            B     B					\n");
    printf("            BBBBBB					\n");
    milli_delay(2000);
    clear();
    printf("\n\n\n\n\n");
    printf("            BBBBBB        Y         Y			\n");
    printf("            B     B        Y       Y			\n");
    printf("            B      B        Y     Y			\n");
    printf("            B      B         Y   Y			\n");
    printf("            B     B           Y Y				\n");
    printf("            BBBBBB             Y				\n");
    printf("            B     B            Y				\n");
    printf("            B      B           Y				\n");
    printf("            B      B           Y				\n");
    printf("            B     B            Y				\n");
    printf("            BBBBBB             Y				\n");
    milli_delay(2000);
    clear();
    printf("\n\n\n\n\n");
    printf("            BBBBBB        Y         Y      EEEEEEEE	\n");
    printf("            B     B        Y       Y       E		\n");
    printf("            B      B        Y     Y        E		\n");
    printf("            B      B         Y   Y         E		\n");
    printf("            B     B           Y Y          E		\n");
    printf("            BBBBBB             Y           EEEEEEEE	\n");
    printf("            B     B            Y           E		\n");
    printf("            B      B           Y           E		\n");
    printf("            B      B           Y           E		\n");
    printf("            B     B            Y           E		\n");
    printf("            BBBBBB             Y           EEEEEEEE	\n");
    printf("----------------------------Goodbye-------------------------");
}
```

### 开机画面
当打开终端时，系统页面会显示出开机动画，字母数字逐渐显示，通过数次改变屏幕的颜色点，达到一个动画效果。

<img src='action.png'>

通过简单的配色之后，利用几个时间函数将开机动画表现出来，这段代码在sl.h文件中，开机动画函数sl（）在kernal_main()中调用，显示动画后通过clear（）清屏，并正式进入系统页面。


void init_palette(void)
{
    static unsigned char table_rgb[48] = {

		0x00, 0x00, 0x00,0xff, 0x00, 0x00,0x00, 0xff, 0x00,0xff, 0xff, 0x00,0x00, 0x00, 0xff,0xff, 0x00, 0xff,
		0x00, 0xff, 0xff,0xff, 0xff, 0xff,0xc6, 0xc6, 0xc6,0x84, 0x00, 0x00,0x00, 0x84, 0x00,0x84, 0x84, 0x00,
		0x00, 0x00, 0x84,0x84, 0x00, 0x84,0x00, 0x84, 0x84,0x84, 0x84, 0x84
	};
	unsigned char table2[216*3] ;
	int r,g,b ;
	set_palette(0, 15, table_rgb);
	for (b = 0; b < 6; b++) {
		for (g = 0; g < 6; g++) {
			for (r = 0; r < 6; r++) {
				table2[(r + g * 6 + b * 36) * 3 + 0] = r * 51;
				table2[(r + g * 6 + b * 36) * 3 + 1] = g * 51;
				table2[(r + g * 6 + b * 36) * 3 + 2] = b * 51;
			}
		}
	}
	set_palette(16, 231, table2);
    return;
}


void set_palette(int start, int end, unsigned char *rgb)
{

    int i, eflags;
    eflags = io_load_eflags();
    io_cli();
    io_out8(0x03c8, start);
    for (i = start; i <= end; i++) {
        io_out8(0x03c9, rgb[0] / 4);
        io_out8(0x03c9, rgb[1] / 4);
        io_out8(0x03c9, rgb[2] / 4);
        rgb += 3;
    }
    io_store_eflags(eflags);
    return;
}


PUBLIC void sl(){

clear();

	int len = 80 * 25,n=0;
	u8 *pch = (u8*)V_MEM_BASE;
	while (--len >= 0) {
		pch[n++] = ' ';
		pch[n++]= 60;
	}
	len = 2000;
	n = 0;
		char img1[25][80]={
	//与image3类似，不再重复，
	};
	char img2[25][80]={
	//与image3类似，不再重复
	};



      char image3[25][80]={
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,27,27,27,27,
    27,27,60,60,60,60,60,60,60,60,60,60,60,60,27,27,
    27,27,27,27,27,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,27,27,27,27,27,27,
    27,27,27,27,60,60,60,60,60,60,60,60,60,27,27,27,
    27,60,60,27,27,27,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,27,27,27,60,60,60,60,
    60,60,27,27,27,60,60,60,60,60,60,60,27,27,27,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,27,27,27,60,60,60,60,
    60,60,27,27,27,60,60,60,60,60,60,60,27,27,27,60,
    60,60,60,60,60,60,60,60,60,60,60,60,27,27,27,60,
    60,60,60,27,27,27,60,60,60,60,60,27,27,27,60,60,
    60,60,27,27,27,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,27,27,27,60,60,60,60,
    60,60,27,27,27,60,60,60,60,60,60,60,60,27,27,27,
    27,27,27,27,27,60,60,60,60,60,60,27,60,60,60,27,
    60,60,27,60,60,60,27,60,60,60,27,60,60,60,27,60,
    60,27,60,60,60,27,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,27,27,27,60,60,60,60,
    60,60,27,27,27,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,27,27,27,60,60,60,60,60,60,60,60,27,60,
    60,60,27,60,60,60,27,60,60,60,60,60,60,27,60,60,
    60,27,60,60,60,27,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,27,27,27,27,27,27,
    27,27,27,27,60,60,60,60,60,60,60,60,27,27,27,27,
    60,60,27,27,27,27,60,60,60,60,60,60,27,27,60,60,
    60,60,27,60,60,60,27,60,60,60,60,27,27,60,60,60,
    60,27,60,60,60,27,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,27,27,27,27,
    27,27,60,60,60,60,60,60,60,60,60,60,60,27,27,27,
    27,27,27,27,27,60,60,60,60,60,60,27,27,27,27,27,
    60,60,60,27,27,27,60,60,60,60,27,27,27,27,27,60,
    60,60,27,27,27,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,
    60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60

}；

	milli_delay(15000);
	for(int i=5;i<20;i++){
	for(int j=7;j<23;j++){
	pch[2*(80*i+j)]=' ';
	pch[2*(80*i+j)+1]=img1[i][j];
	}
	}
	milli_delay(15000);
	for(int i=5;i<20;i++){
	for(int j=26;j<40;j++){
	pch[2*(80*i+j)]=' ';
	pch[2*(80*i+j)+1]=img2[i][j];
	}
	}
	milli_delay(15000);
	for(int i=10;i<20;i++){
	for(int j=41;j<71;j++){
	pch[2*(80*i+j)]=' ';
	pch[2*(80*i+j)+1]=image3[i][j];
	}
	}
	milli_delay(15000);
	console_table[current_console].cursor=2000;
	clear();
}


## 系统级应用
### 保存并展示bmp图片文件
借助文件系统已经搭建好的文件系统，将已经储存在bmp.h文件中的颜色点数组写入新创建的文件中，展示时，将颜色点展示在屏幕上。

<img src='createimg.png'>

通过showimage（）函数展示图片

<img src='showimg.png'>

相关代码写入kernal.c文件中

```c

void saveimage(char* path, char* file)//
{

CreateFile(path,file);
char absoPath[512];
	addTwoString(absoPath, path, file);
	int fd=open(absoPath,O_RDWR);
	//write
	
	unsigned char buf[2003]={0};
	for(int i=0;i<25;i++){
	for(int j=0;j<80;j++){
	buf[i*80+j]=bmp[i][j];
	}
	}
	buf[2000]=0;
	write(fd,buf,2000);
	printf("File writed. fd:%d\n",fd);
	
	close(fd);
	
}


    void showimage(char* path,char* file){
    clear();
    char absoPath[512];
	addTwoString(absoPath, path, file);
	int fd=open(absoPath,O_RDWR);
	unsigned char IMG[2000];
	read(fd,IMG,2000);
	
	int len=0,n=0;
	u8 *pch = (u8*)V_MEM_BASE;
	while (len++ < 2000) {
		pch[n++] = ' ';
		pch[n++]= IMG[len];
	}
	milli_delay(30000);
	console_table[current_console].cursor=2000;
	clear();
	close(fd);
}

```

## 成员分工

|姓名 | 学号 | 分工 |
|  :----:| :----: |  :------------------:|
| 戴蓓佳 | 1850724 |  关机动画 计算器|
| 杨世吉 | 1850948 | 推箱子游戏 |
| 田文凯 | 1852040 | 文件系统改进 |
| 龚钰琦 | 1852489 | 开机动画 图片显示 |
| 沈钰姣 | 1852040 | 进程系统现实 贪吃蛇游戏 扫雷游戏 |


