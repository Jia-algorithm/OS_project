#include"stdio.h"
#include"rand.h"
#define MAX_ROW 8
#define MAX_COL 8

int Boxs;
int x, y;


int map[MAX_ROW][MAX_COL] = {
	 0, 0, 1, 1, 1, 0, 0, 0 ,
	 0, 0, 1, 4, 1, 0, 0, 0 ,
	 0, 0, 1, 0, 1, 1, 1, 1 ,
	 1, 1, 1, 3, 0, 3, 4, 1,
	 1, 4, 0, 3, 2, 1, 1, 1 ,
	 1, 1, 1, 1, 3, 1, 0, 0 ,
	 0, 0, 0, 1, 4, 1, 0, 0 ,
	 0, 0, 0, 1, 1, 1, 0, 0 
};

PUBLIC void sokoban() {
	int i = 0;
	int choice = 0;
	MenuUi();
	Game();
}

void MenuUi() {
	printf("\t----------------------------------------------------------------\n");
	printf("\t|                                                              |\n");
	printf("\t|                Welcome to sokoban game!                      |\n");
	printf("\t|                                                              |\n");
	printf("\t|                 ._______________________.                    |\n");
	printf("\t|                 | _____________________ |                    |\n");
	printf("\t|                 | I                   I |                    |\n");
	printf("\t|                 | I                   I |                    |\n");
	printf("\t|                 | I      sokoban      I |                    |\n");
	printf("\t|                 | I                   I |                    |\n");
	printf("\t|                 | I___________________I |                    |\n");
	printf("\t|                 !_______________________!                    |\n");
	printf("\t|                     ._[__________]_.                         |\n");
	printf("\t|                 .___|_______________|___.                    |\n");
	printf("\t|                  |::: ____             |                     |\n");
	printf("\t|                  |    ~~~~ [CD-ROM]    |                     |\n");
	printf("\t|                  !_____________________!                     |\n");
	printf("\t|                                                              |\n");
	printf("\t|                                                              |\n");
	printf("\t|                    Dare to challenge!                        |\n");
	printf("\t|                                                              |\n");
	printf("\t|                                                              |\n");
	printf("\t|       1.start the game          0.leave the game             |\n");
	printf("\t|                                                              |\n");
	printf("\t----------------------------------------------------------------\n");
}


void InitData() {
	int i, j;
	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COL; j++) {
			if (map[i][j] == 2) {
				x = j;
				y = i;
			}

			if (map[i][j] == 3) {
				Boxs++;
			}
		}
	}
}
void drawMap() {
	int i, j;
	for (i = 0; i < MAX_ROW; i++) {
		for (j = 0; j < MAX_COL; j++) {
			switch (map[i][j]) {
			case 0:
				printf("  ");
				break;
			case 1:
				printf("|");
				break;
			case 2:
				printf("@");
				break;
			case 3:
				printf("#");
				break;
			case 4:
				printf("$");
				break;
			case 5:
				printf("&");
				break;
			}
		}
		printf("\n");
	}
}

void MoveUp() {
	if (y == 0) {
		return;
	}
	int Ux = x;
	int Uy = y - 1;
	if (map[Uy][Ux] == 1 || map[Uy][Ux] == 5) {
		return;
	}
	if (map[Uy][Ux] == 3) {
		if (map[Uy - 1][Ux] == 1) {
			return;
		}
		if (map[Uy - 1][Ux] == 4) {
			map[Uy - 1][Ux] = 5;
			Boxs--;
		}
		else {
			map[Uy - 1][Ux] = 3;
		}
	}
	map[y][x] = 0;
	map[Uy][Ux] = 2;
	y = Uy;
}

void MoveDown() {
	int D = MAX_ROW - 1;
	if (y == D) {
		return;
	}
	int Dx = x;
	int Dy = y + 1;
	if (map[Dy][Dx] == 1 || map[Dy][Dx] == 5) {
		return;
	}
	if (map[Dy][Dx] == 3) {
		if (map[Dy + 1][Dx] == 1) {
			return;
		}
		if (map[Dy + 1][Dx] == 4) {
			map[Dy + 1][Dx] = 5;
			Boxs--;
		}
		else {
			map[Dy + 1][Dx] = 3;
		}
	}
	map[y][x] = 0;
	map[Dy][Dx] = 2;
	y = Dy;
}


void MoveLeft() {
	if (x == 0) {
		return;
	}
	int Lx = x - 1;
	int Ly = y;

	if (map[Ly][Lx] == 1 || map[Ly][Lx] == 5) {
		return;
	}
	if (map[Ly][Lx] == 3) {
		if (map[Ly][Lx - 1] == 1) {
			return;
		}
		if (map[Ly][Lx - 1] == 4) {
			map[Ly][Lx - 1] = 5;
			Boxs--;
		}
		else {
			map[Ly][Lx - 1] = 3;
		}
	}
	map[y][x] = 0;
	map[Ly][Lx] = 2;
	x = Lx;
}


void MoveRight() {
	int R = MAX_COL - 1;
	if (x == R) {
		return;
	}
	int Rx = x + 1;
	int Ry = y;
	if (map[Ry][Rx] == 1 || map[Ry][Rx] == 5) {
		return;
	}
	if (map[Ry][Rx] == 3) {
		if (map[Ry][Rx + 1] == 1) {
			return;
		}
		if (map[Ry][Rx + 1] == 4) {
			map[Ry][Rx + 1] = 5;
			Boxs--;
		}
		else {
			map[Ry][Rx + 1] = 3;
		}
	}
	map[y][x] = 0;
	map[Ry][Rx] = 2;
	x = Rx;
}



void Game() {
	char direction[2] = "";
	InitData();
	while (1) {
		drawMap();
		printf("Please enter the direction(lowercase):(w is up,A is left,S is down,D is right)\n");
		if (!Boxs) {
			break;
		}
		read(3, direction, 1);
		switch (direction[0]) {
		case 'w':
			MoveUp();
			break;
		case 'a':
			MoveLeft();
			break;
		case 's':
			MoveDown();
			break;
		case 'd':
			MoveRight();
			break;
		}
	}
	printf("GAME OVER!YOU ARE WINNER!\n");
}



